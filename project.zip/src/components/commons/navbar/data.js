export const MenuData = [
  {
    name: "About us",
    url: "/about-us",
  },
  {
    name: "What We do",
    url: "/what-we-do",
  },
  {
    name: "Our work",
    url: "/our-work",
  },
  {
    name: "Blog",
    url: "/blog",
  },
  {
    name: "Say hi",
    url: "/say-hi",
  },
];
