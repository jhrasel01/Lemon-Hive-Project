import { Home } from "@/components/homePage/Home";

export default function page() {
  return <Home />;
}
