import Conference from "@/components/conferencePage/Conference";

export default function page() {
  return (
    <>
      <Conference />
    </>
  );
}
