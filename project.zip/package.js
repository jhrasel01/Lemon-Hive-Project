// 1. npm install react-icons --save
// 2. npm install -D tailwindcss
// 3. npx tailwindcss init
// 4.
// 5.
// 6.
// 7.
// 8.
// 9.
// 10.
